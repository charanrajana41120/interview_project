import json
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.core.management import execute_from_command_line
from interview_project.settings import FILES

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_group_name = 'chat_room'
        
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        print("server stopped by calling disconnect")
        message = "True"
       
        # Save the message to a text file
        self.save_to_file(f"{FILES}/stop_server.txt", message)
        
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        print("inside the receive method")
        print(f"received called {text_data}")

        # Parse the text_data if it's JSON, otherwise just save the raw text
        try:
            data = json.loads(text_data)
            message = data.get('message', text_data)
        except json.JSONDecodeError:
            message = text_data

        # Save the message to a text file
        self.save_to_file(f"{FILES}/answer.txt", message)

    def save_to_file(self, filename, message):
        with open(filename, 'w') as file:
            file.write(message)

    async def chat_message(self, event):
        message = event['message']

        await self.send(text_data=json.dumps({
            'message': message
        }))

    async def get_input(self, event):
        print("this is called chat_message with get_input")
        message = event['message']

        await self.send(text_data=json.dumps({
            'get_input': message
        }))
        
    
    async def close(self, event):
        print("this is called close")
        message = event['message']
        print(message)

        await self.send(text_data=json.dumps({
            'close': message
        }))
