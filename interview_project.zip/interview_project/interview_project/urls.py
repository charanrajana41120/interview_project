
from django.contrib import admin
from django.urls import path,include
from interview import views
from . import routing




urlpatterns = [
    path('resume_upload/', views.upload_resume),
    path('form_upload/',views.form_upload),
    path('run_interview/', views.run_interview),
    path('store_data/', views.save_data_from_json),
    path('login/', views.ValidatingAdmin),
    path('adminform/', views.save_data_from_json),
    path("interview-results/", views.InterviewHistory),
    path("interviewee-login/",views.IntervieweeLogin),

]

