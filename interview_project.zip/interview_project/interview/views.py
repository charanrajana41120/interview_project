from django.shortcuts import render
import os
import json
import PyPDF2
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import default_storage
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import ResumeDataSerializer,FormDataSerializer
from openai import OpenAI
import autogen
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import time
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import AdminLogin,InterviewResults,IntervieweeLogin
import re
from openai import OpenAI
from .autogen_agents import GenerateAgentsWithArgs
from .models import ModifyAgentsSettings
import asyncio
from interview_project.settings import FILES
API_KEY = settings.OPENAI_API_KEY


# Create your views here. 



#################### API #############################
@api_view(['GET'])
def InterviewHistory(request):
    results = InterviewResults.objects.all()
    data = list(results.values())  # Serialize queryset to list of dictionaries
    return JsonResponse(data, safe=False)


@api_view(['POST'])
def IntervieweeLogin(request):
    print("validating interviewee logins....")
    user_id = request.data.get('userId')
    password = request.data.get('password')
    print(user_id,password)

    try:
        # Check if admin with provided user_id exists
        admin = get_object_or_404(IntervieweeLogin, userId=user_id)

        
        if admin.password == password:
            return Response({'success': True}, status=status.HTTP_200_OK)
        else:
            return Response({'failed': False, 'error': 'Invalid password'}, status=status.HTTP_401_UNAUTHORIZED)

    except:
        return Response({'failed': False, 'error': 'interviewee not found'}, status=status.HTTP_404_NOT_FOUND)

    




@api_view(['POST'])
def ValidatingAdmin(request):
    print("validating.....")
    # Extract data from request payload
    user_id = request.data.get('userId')
    password = request.data.get('password')
    print(user_id,password)

    try:
        # Check if admin with provided user_id exists
        admin = get_object_or_404(AdminLogin, userId=user_id)

        
        if admin.password == password:
            return Response({'success': True}, status=status.HTTP_200_OK)
        else:
            return Response({'failed': False, 'error': 'Invalid password'}, status=status.HTTP_401_UNAUTHORIZED)

    except AdminLogin.DoesNotExist:
        return Response({'failed': False, 'error': 'Admin not found'}, status=status.HTTP_404_NOT_FOUND)

    




@api_view(['POST'])  
def save_data_from_json(request):
    
    json_data=request.data

    try:
        # Creating a new instance of ModifyAgentsSettings and saving it
        settings_instance = ModifyAgentsSettings(
            Agent1_Role=json_data.get('agent1'),
            Agent2_Role=json_data.get('agent2'),
            Agent_1_Reply=int(json_data.get('reply1')),
            Agent_2_Reply=int(json_data.get('reply2')),
            Agent_3_Reply=int(json_data.get('reply3'))
        )
        settings_instance.save()

        return JsonResponse({'message': 'Data saved successfully'}, status=201)
    
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)




@api_view(['POST'])
def upload_resume(request):
    print("resume upload function called")
    serializer = ResumeDataSerializer(data=request.data)
    if serializer.is_valid():
        if 'resume' in request.FILES:
            resume_file = request.FILES['resume']
            resume_path = os.path.join(settings.MEDIA_ROOT, resume_file.name)
            with open(resume_path, 'wb+') as destination:
                for chunk in resume_file.chunks():
                    destination.write(chunk)
            
            with open(resume_path, 'rb') as file:
                pdf = PyPDF2.PdfReader(file)
                text = ''
                for page in range(len(pdf.pages)):
                    text += pdf.pages[page].extract_text()
            print(text)
            os.remove(resume_path)
            client = OpenAI(api_key=API_KEY)

            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "user", "content": f'Extract name, projects, skills, and experience (if available) from the following text: {text}. Once extracted, return a dictionary with the following structure: {{"name":"fill here","skills":"fill here","projects":"fill here","experience":"fill here"}}. If experience is not found in the text, fill it with "NA".'}
                ]
            )

            content = response.choices[0].message.content.strip()
            extracted_dict = json.loads(content)
            print(extracted_dict)

            
            return Response(extracted_dict, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def form_upload(request):
    print("form upload function called")
    serializer = FormDataSerializer(data=request.data)
    
    if serializer.is_valid():
        print("Serializer is valid")
        print(serializer.validated_data)

        
        
        
        return Response(serializer.validated_data, status=status.HTTP_200_OK)
    else:
        print("Serializer errors:", serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def run_interview(request):

    try:
        # Retrieve the most recently added instance of ModifyAgentsSettings
        latest_settings_instance = ModifyAgentsSettings.objects.latest('id')
        
        # Assign values to variables
        Role1 = latest_settings_instance.Agent1_Role
        Role2 = latest_settings_instance.Agent2_Role
        Agent_1_Reply = latest_settings_instance.Agent_1_Reply
        Agent_2_Reply = latest_settings_instance.Agent_2_Reply
        Agent_3_Reply = latest_settings_instance.Agent_3_Reply
        
        # Example usage or further processing if needed
        Max_turns_list = [Agent_1_Reply + 1, Agent_2_Reply + 1, Agent_3_Reply + 1]
        print("interview details : ", Role1 , Role2, Agent_1_Reply,Agent_2_Reply,Agent_3_Reply)
            
    except Exception as e:
        print("error while getting values from databse")
     

    with open(f"{FILES}/answer.txt", 'w') as file:
            file.write('')
    with open(f"{FILES}/stop_server.txt", 'w') as file:
            file.write('')

    with open(f"{FILES}/results.txt", 'w') as file:
            file.write('')
    
    print("run interview executed with json data:")
    interviewee_name = request.data.get('name')
    interviewee_skills = request.data.get('skills')
    interviewee_projects = request.data.get('projects')
    interviewee_experience = request.data.get('experience')
    print(f"the for agents values : {interviewee_name},{interviewee_skills},{interviewee_projects},{interviewee_experience}")
    if interviewee_name and interviewee_skills and interviewee_projects and interviewee_experience:
        
        agent_obj = GenerateAgentsWithArgs(
            role1=Role1,
            role2=Role2,
            name=interviewee_name,
            skills=interviewee_skills,
            projects=interviewee_projects,
            experience=interviewee_experience,
            agent1_reply=Agent_1_Reply,
            agent2_reply=Agent_2_Reply,
            agent3_reply=Agent_3_Reply
        )
        print("Agents initiated")
        result = agent_obj.call_agents(max_turns_list=Max_turns_list, msg_list=["with_id:#2#1 good morning Lets start the interview !!!", f"with_id:#2#1 {Role1} Round completed", f"with_id:#2#1 {Role2} round completed"])
        final_result = f"interviewee details: name : {interviewee_name}, skills : {interviewee_skills} , projects : {interviewee_projects} ,experience : {interviewee_experience} .---------------------------------- interview completed. Results: 1. {Role1}: {result[0].summary}, 2. {Role2}: {result[1].summary}, 3. HR: {result[2].summary}"
        print(final_result)
                
        
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            'chat_room',
            {
                'type': 'close',
                'message': "interview completed"
            }
        )
        result1 = InterviewResults(results=final_result)
        result1.save()

        
        return Response({"message": "interview completed"}, status=status.HTTP_200_OK)
    else:
        print("Required session data not found")
        return Response({"message": "Interview not completed"}, status=status.HTTP_400_BAD_REQUEST)
    

##################################################################################################################################################


