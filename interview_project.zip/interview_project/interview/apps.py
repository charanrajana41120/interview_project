
from django.apps import AppConfig

class InterviewProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'interview'
    verbose_name = 'Interview Project'
