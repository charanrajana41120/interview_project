from django.db import models    
from django.db import models

class ModifyAgentsSettings(models.Model):
    Agent1_Role=models.CharField(max_length=40)
    Agent2_Role=models.CharField(max_length=40)
    Agent_1_Reply=models.IntegerField()
    Agent_2_Reply=models.IntegerField()
    Agent_3_Reply=models.IntegerField()



class AdminLogin(models.Model):
    userId = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=100)


class IntervieweeLogin(models.Model):
    userId = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=100)

class InterviewResults(models.Model):
    results = models.TextField(unique=True)
        


