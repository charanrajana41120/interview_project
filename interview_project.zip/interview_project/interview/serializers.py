# interview_app/serializers.py

from rest_framework import serializers

class FormDataSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100, required=False)
    skills = serializers.CharField(max_length=500, required=False)
    projects = serializers.CharField(max_length=1000, required=False)
    experience = serializers.CharField(max_length=500, required=False)
    
class ResumeDataSerializer(serializers.Serializer):
    resume = serializers.FileField(required=False)



class ExtractTextSerializer(serializers.Serializer):
    pdf_url = serializers.URLField(required=False)
    pdf_path = serializers.CharField(required=False)