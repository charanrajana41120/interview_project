
from django.contrib import admin
from .models import ModifyAgentsSettings,InterviewResults,AdminLogin,IntervieweeLogin

admin.site.register(ModifyAgentsSettings)
admin.site.register(InterviewResults)
admin.site.register(AdminLogin)
admin.site.register(IntervieweeLogin)





